
import { useNavigate } from 'react-router-dom';
import welcomeImage from '../img/welcome-pets.png';
const Welcome = () => {
  const navigate = useNavigate();

  return (
    <div className="phone-container">
      <div className="top-decoration"></div>
      <div className="bottom-decoration"></div>
      <div className="screen">
        <h1>Welcome</h1>
     <h2>Your trusted partner for stress-free pet grooming and care!</h2>

        <div className="welcome-image">
          <img src={welcomeImage} alt="Pet grooming illustration" />
        </div>

        <div className="dots">
          <div className="dot active"></div>
          <div className="dot"></div>
          <div className="dot"></div>
        </div>

        <button className="button" onClick={() => navigate('/signin')}>
          Get Started <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
            <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0zM4.5 7.5a.5.5 0 0 0 0 1h5.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H4.5z"/>
          </svg>
        </button>
      </div>
    </div>
  );
};

export default Welcome;

