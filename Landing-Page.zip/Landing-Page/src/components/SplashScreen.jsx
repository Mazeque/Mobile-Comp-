
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import '../App.css';
import logoImage from '../img/furryfresh-logoS.png';

const SplashScreen = () => {
  const [isVisible, setIsVisible] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {

    const img = new Image();
    img.src = logoImage;

  
    const timer = setTimeout(() => {
      setIsVisible(false);
      navigate('/welcome');
    }, 5000);

    
    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className={`splash-screen ${isVisible ? 'visible' : 'hidden'}`}>
      <div className="phone-container">
        <div className="screen">
          <div className="splash-content">
            <div className="logo-container">
              <img src={logoImage} alt="Furry Fresh Logo" className="splash-logo" />
            </div>
            <div className="loading-spinner-container">
              <div className="loading-spinner"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SplashScreen;